package ru.geekbrains.testapp.dto;

public class PersonDto {
}
