package ru.geekbrains.testapp.service.impl;

import ru.geekbrains.testapp.service.SaveDataService;

public class SaveDataServiceImpl implements SaveDataService {
}
