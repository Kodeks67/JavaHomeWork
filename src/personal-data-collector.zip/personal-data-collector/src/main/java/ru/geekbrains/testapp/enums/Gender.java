package ru.geekbrains.testapp.enums;

public enum Gender {
    m,
    f;
    private String value;

    Gender(String value) {
        this.value = value;
    }

    Gender() {

    }
}
