package ru.geekbrains.testapp.dto;

import ru.geekbrains.testapp.enums.Gender;

public class PersonInfoDto extends PersonDto{

 private String firstname;

 public String getFirstname() {
  return firstname;
 }

 public void setFirstname(String firstname) {
  this.firstname = firstname;
 }

 public String getLastname() {
  return lastname;
 }

 public void setLastname(String lastname) {
  this.lastname = lastname;
 }

 public String getPatronymic() {
  return patronymic;
 }

 public void setPatronymic(String patronymic) {
  this.patronymic = patronymic;
 }

 public int getPhoneNumber() {
  return phoneNumber;
 }

 public void setPhoneNumber(int phoneNumber) {
  this.phoneNumber = phoneNumber;
 }

 public Gender getGender() {
  return gender;
 }

 public void setGender(Gender gender) {
  this.gender = gender;
 }

 public String getBirthday() {
  return birthday;
 }

 public void setBirthday(String  birthday) {
  this.birthday = birthday;
 }

 private String lastname;
 private String  patronymic;
 private int phoneNumber;
 private Gender gender;

 private String birthday;

}
