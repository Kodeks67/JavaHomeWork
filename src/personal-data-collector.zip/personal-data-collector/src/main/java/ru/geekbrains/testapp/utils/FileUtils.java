package ru.geekbrains.testapp.utils;

import java.util.List;

public class FileUtils {

    public static int findPosition(List<String> lines, String lineToLookFor, InsertPosition position) {

        for (int i = 0; i < lines.size(); i++) {
            if (lineToLookFor.equals(lines.get(i))) {
                if (position == InsertPosition.BEFORE) {
                    return i;
                } else if (position == InsertPosition.AFTER) {
                    return i + 1;
                }
            }
        }

        return -1;
    }
}
