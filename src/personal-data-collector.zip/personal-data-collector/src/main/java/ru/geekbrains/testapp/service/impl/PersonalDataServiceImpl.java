package ru.geekbrains.testapp.service.impl;

import ru.geekbrains.testapp.dto.PersonInfoDto;
import ru.geekbrains.testapp.exceptions.ApiError;
import ru.geekbrains.testapp.exceptions.ApiException;
import ru.geekbrains.testapp.service.PersonalDataService;
import ru.geekbrains.testapp.utils.InsertPosition;
import ru.geekbrains.testapp.utils.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static java.util.Objects.isNull;
import static ru.geekbrains.testapp.utils.FileUtils.findPosition;

public class PersonalDataServiceImpl implements PersonalDataService {
    @Override
    public HashMap<String, List<String>> addPersonInfoToMap(PersonInfoDto personInfoDto) {
        LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
        if (personInfoDto.getLastname()==null) {
            throw new ApiException(ApiError.MAP_KEY_IS_NULL);
        }
        map.put(personInfoDto.getLastname(), List.of(personInfoDto.getLastname(), personInfoDto.getFirstname(), personInfoDto.getPatronymic(),
                String.valueOf(personInfoDto.getBirthday()), String.valueOf(personInfoDto.getPhoneNumber()),
                String.valueOf(personInfoDto.getGender())));
        return map;
    }

    @Override
    public void addPersonInfoToDoc(HashMap map) {
        Map.Entry<String, List<String>> entry = (Map.Entry<String, List<String>>) map.entrySet().iterator().next();
        String filename = entry.getKey();
        File file = new File(filename);
        try {
            if (!file.createNewFile()) {
                 addDataToExistingFile(filename, map);
            } else {
                createNewFileAndAddData(filename, map);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private void addDataToExistingFile(String filename, HashMap map) {
        try {
            Path path = Paths.get(filename);
            List<String> lines = Files.readAllLines(path);
            int position = lines.size()-1;

            lines.add(position, map.get(filename).toString());
            Files.write(path, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void createNewFileAndAddData(String filename, HashMap map) {
        try {
            Files.write(Paths.get(filename), map.get(filename).toString().getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public PersonInfoDto getPersonalInfoDto(String insert) {
        if (isNull(insert)) {
            throw new ApiException(ApiError.NO_DATA_IS_INSERTED);
        }
        PersonInfoDto personInfoDto = new PersonInfoDto();
        try {
            personInfoDto = StringUtils.parseString(insert);
            return personInfoDto;
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
}
