package ru.geekbrains.testapp.exceptions;
public class ApiException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ApiError getApiError() {
    return apiError;
  }

  /**
   * ApiError
   */
  private final ApiError apiError;


  public ApiException(ApiError apiError) {
    super(apiError.getDisplayMessage());
    this.apiError = apiError;
  }
}