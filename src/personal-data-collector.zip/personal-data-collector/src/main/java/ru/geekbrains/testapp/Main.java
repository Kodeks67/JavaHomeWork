package ru.geekbrains.testapp;

import ru.geekbrains.testapp.dto.PersonInfoDto;
import ru.geekbrains.testapp.service.impl.PersonalDataServiceImpl;

import java.util.Scanner;



public class Main {

    public static void main(String[] args) {
        System.out.println("Hello user! Please enter your personal data =) ");
        PersonalDataServiceImpl personalDataService = new PersonalDataServiceImpl();
        //считываем данные с клавиатуры
        String insert = getScannered();
        //валидируем их и записываем данные в дто объект
        PersonInfoDto personInfoDto = personalDataService.getPersonalInfoDto(insert);
        //записываем объект в файл
       personalDataService.addPersonInfoToDoc(personalDataService.addPersonInfoToMap(personInfoDto));
    }

    private static String getScannered() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }


}