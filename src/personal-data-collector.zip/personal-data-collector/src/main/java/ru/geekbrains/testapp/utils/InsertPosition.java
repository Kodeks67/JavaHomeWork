package ru.geekbrains.testapp.utils;

public enum InsertPosition {
        BEFORE, AFTER;
    }