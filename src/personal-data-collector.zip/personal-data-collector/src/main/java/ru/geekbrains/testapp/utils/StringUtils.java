package ru.geekbrains.testapp.utils;

import ru.geekbrains.testapp.dto.PersonInfoDto;
import ru.geekbrains.testapp.enums.Gender;
import ru.geekbrains.testapp.exceptions.ApiError;
import ru.geekbrains.testapp.exceptions.ApiException;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtils {

    public static final String DATA_FORMATTER = "dd.mm.yyyy";
    public static final String NAME_PATTERN ="^[а-я]+$";

    public static PersonInfoDto parseString(String string) throws ParseException {
        String[] array = string.split(" ");
        if (array.length < 6) {
            throw new ApiException(ApiError.QUANTITY_DATA_IS_LESS);
        }
        if (array.length > 6){
            throw new ApiException(ApiError.TOO_MANY_QUANTITY_DATA);
        }
        //TODO проверка на вхождеие для произвольного ввода
        return getPersonInfoDto(array);
    }

    private static PersonInfoDto getPersonInfoDto(String[] array) {
        PersonInfoDto personInfoDto = new PersonInfoDto();
        personInfoDto.setLastname(getName(array[0]));
        personInfoDto.setFirstname(getName(array[1]));
        personInfoDto.setPatronymic(getName(array[2]));
        personInfoDto.setBirthday(parseDate(array[3]));
        personInfoDto.setPhoneNumber(getNumber(array[4]));
        personInfoDto.setGender(getGender(array[5]));
        return personInfoDto;
    }

    private static int getNumber(String s) {
       //TODO добавить проверку на наличие 0 вначале строки
        int number;
        try {
            number = Integer.parseInt(s);
            if (number <= 0) {
                throw new ApiException(ApiError.PHONE_NUMBER_FORMAT_IS_NOT_VALID);
            }
        } catch (NumberFormatException e) {
            throw new ApiException(ApiError.PHONE_NUMBER_FORMAT_IS_NOT_VALID);
        }
        return number;
    }

    private static String parseDate(String entry) {
        Date birthday;
        SimpleDateFormat dataTimeFormatter = new SimpleDateFormat(DATA_FORMATTER);
        try {
            birthday = dataTimeFormatter.parse(entry);
            return dataTimeFormatter.format(birthday);
        } catch (ParseException e) {
            throw new ApiException(ApiError.BIRTHDAY_DATE_FORMAT_IS_NOT_VALID);
        }
    }

    private static Gender getGender(String entry) {
        try {
            return Gender.valueOf(entry);
        } catch (IllegalArgumentException e) {
            throw new ApiException(ApiError.GENDER_FORMAT_IS_NOT_VALID);
        }
    }

    private static String getName(String entry){
        Pattern pattern = Pattern.compile(NAME_PATTERN,
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Matcher matcher = pattern.matcher(entry);
        if (!matcher.find()){
            throw new ApiException(ApiError.FIO_FORMAT_IS_NOT_VALID);
        } else {
            return entry;
        }
    }
}

