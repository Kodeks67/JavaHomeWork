package ru.geekbrains.testapp.service;

public interface SaveDataService {
}
