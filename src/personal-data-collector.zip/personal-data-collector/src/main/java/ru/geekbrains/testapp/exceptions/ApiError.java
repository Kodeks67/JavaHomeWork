package ru.geekbrains.testapp.exceptions;

public enum ApiError {

    QUANTITY_DATA_IS_LESS("QUANTITY_DATA_IS_LESS"),
    TOO_MANY_QUANTITY_DATA("TOO_MANY_QUANTITY_DATA"),
    NO_DATA_IS_INSERTED("NO_DATA_IS_INSERTED"),
    BIRTHDAY_DATE_FORMAT_IS_NOT_VALID("BIRTHDAY_DATE_FORMAT_IS_NOT_VALID"),
    PHONE_NUMBER_FORMAT_IS_NOT_VALID("PHONE_NUMBER_FORMAT_IS_NOT_VALID"),
    GENDER_FORMAT_IS_NOT_VALID("GENDER_FORMAT_IS_NOT_VALID"),
    FIO_FORMAT_IS_NOT_VALID("FIO_FORMAT_IS_NOT_VALID"),
    MAP_KEY_IS_NULL("MAP_KEY_IS_NULL");

    ApiError(String displayMessage) {
        this.displayMessage = displayMessage;
    }

    private String displayMessage;
    public String getDisplayMessage() {
        return displayMessage;
    }
}
