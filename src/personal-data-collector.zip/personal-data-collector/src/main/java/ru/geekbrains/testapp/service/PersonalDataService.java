package ru.geekbrains.testapp.service;

import ru.geekbrains.testapp.dto.PersonInfoDto;

import java.util.HashMap;
import java.util.List;

public interface PersonalDataService {
    PersonInfoDto getPersonalInfoDto(String string);
    HashMap<String , List<String>> addPersonInfoToMap(PersonInfoDto personInfoDto);

    void addPersonInfoToDoc(HashMap map);
}
